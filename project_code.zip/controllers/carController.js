const Car = require('../models/Car');
const { getCarSpecs } = require('../services/externalApiService');


exports.createCar = async (req, res) => {
    try {
      const { brand, model, year, imageUrl } = req.body;
  
      const specs = await getCarSpecs(brand, model, year);
      console.log("Specs fetched from API:", specs); 
  
      const car = await Car.create({
        ...req.body,
        owner: req.user.id,           
        specs: specs || {},           
        imageUrl: imageUrl || ""      
      });
  
      res.status(201).json(car);
  
    } catch (error) {
      console.error("Error creating car:", error.message);
      res.status(500).json({ message: "Failed to create car", error: error.message });
    }
  };

exports.getCars = async (req, res) => {
  const queryObj = { owner: req.user.id };
  if (req.query.brand) queryObj.brand = req.query.brand;
  if (req.query.status) queryObj.status = req.query.status;

  const cars = await Car.find(queryObj);
  res.json(cars);
};

exports.getCarById = async (req, res) => {
  const car = await Car.findById(req.params.id);
  if (!car) {
    res.status(404);
    throw new Error('Car not found');
  }
  res.json(car);
};

exports.updateCar = async (req, res) => {
  const car = await Car.findById(req.params.id);

  if (!car) {
    res.status(404);
    throw new Error('Car not found');
  }

  if (car.owner.toString() !== req.user.id) {
    res.status(401);
    throw new Error('Not authorized');
  }

  const updatedCar = await Car.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });

  res.json(updatedCar);
};

exports.deleteCar = async (req, res) => {
  const car = await Car.findById(req.params.id);

  if (!car) {
    res.status(404);
    throw new Error('Car not found');
  }

  if (car.owner.toString() !== req.user.id) {
    res.status(401);
    throw new Error('Not authorized');
  }

  await car.deleteOne();
  res.json({ message: 'Car removed from showroom' });
};