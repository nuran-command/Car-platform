const mongoose = require('mongoose');

const carSchema = new mongoose.Schema(
  {
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    brand: {
      type: String,
      required: [true, 'Please add a brand (e.g., Toyota)']
    },
    model: {
      type: String,
      required: [true, 'Please add a model (e.g., Camry)']
    },
    year: {
      type: Number,
      required: [true, 'Please add a year']
    },
    price: {
      type: Number,
      required: [true, 'Please add a price']
    },
    mileage: {
      type: Number,
      default: 0 
    },
    condition: {
      type: String,
      enum: ['New', 'Used'],
      default: 'Used'
    },
    status: {
      type: String,
      enum: ['In Stock', 'Sold', 'Pending'],
      default: 'In Stock'
    },
    color: {
      type: String
    },
    description: {
      type: String
    },

    specs: {
      type: Object,
      default: {}
    },
    imageUrl: { type: String, default: "" }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model('Car', carSchema);